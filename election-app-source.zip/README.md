# 🗳️ Election Assistant — Election Process Education Assistant

A full-stack, production-ready web application that educates Indian citizens about the election process. Built with React, TypeScript, Express, and Gemini AI.

## ✨ Features

| Feature | Description |
|---|---|
| 🤖 AI Chat Assistant | Gemini-powered "Election Assistant" chatbot — election-scoped, English-friendly |
| 📋 Step-by-Step Guide | Interactive 6-stage election timeline with facts and details |
| 🏛️ Official Resources | Links to NVSP, ECI, Voter Helpline App, cVIGIL |
| ✅ Eligibility Checker | Server-side age + citizenship validator |
| 📍 Booth Locator | Pincode-based mock polling station locator |
| 📱 Responsive Design | Mobile-first, works on phones, tablets, laptops |

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Motion (Framer)
- **Backend**: Node.js, Express, Helmet, express-rate-limit
- **AI**: Google Gemini 2.0 Flash via `@google/genai`
- **Build**: Vite 6
- **Deploy**: Docker + Google Cloud Run

---

## 🚀 Local Development

### Prerequisites
- Node.js 20+
- A [Gemini API key](https://aistudio.google.com/app/apikey) (free)

### Setup

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/election-assistant.git
cd election-assistant

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env and add your GEMINI_API_KEY

# 4. Start development server
npm run dev
# App runs at http://localhost:3000
```

---

## 🐳 Docker

```bash
# Build image
docker build -t election-assistant .

# Run container
docker run -p 8080:8080 -e GEMINI_API_KEY=your_key_here election-assistant

# Visit http://localhost:8080
```

---

## ☁️ Deploy to Google Cloud Run

### One-time setup

```bash
# Install Google Cloud CLI: https://cloud.google.com/sdk/docs/install

# Login
gcloud auth login

# Set your project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable run.googleapis.com cloudbuild.googleapis.com
```

### Deploy

```bash
# Option 1: Deploy directly from source (Cloud Build)
gcloud run deploy election-assistant \
  --source . \
  --platform managed \
  --region asia-south1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=your_key_here \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 10 \
  --port 8080

# Option 2: Build and push manually
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/election-assistant
gcloud run deploy election-assistant \
  --image gcr.io/YOUR_PROJECT_ID/election-assistant \
  --platform managed \
  --region asia-south1 \
  --allow-unauthenticated \
  --set-env-vars GEMINI_API_KEY=your_key_here
```

### Recommended Region
`asia-south1` (Mumbai) — lowest latency for Indian users.

---

## 📁 Project Structure

```
election-assistant/
├── src/
│   ├── components/
│   │   ├── ChatBot.tsx          # AI chat interface
│   │   ├── ElectionGuide.tsx    # 6-step election timeline
│   │   ├── Resources.tsx        # Portals + eligibility checker
│   │   └── PollingBoothLocator.tsx  # Pincode booth locator
│   ├── hooks/
│   │   └── useChat.ts           # Chat state + API logic
│   ├── lib/
│   │   └── utils.ts             # Shared utilities
│   ├── constants.ts             # Steps, resources, stats data
│   ├── App.tsx                  # Root layout
│   ├── main.tsx                 # Entry point
│   └── index.css                # Global styles + design tokens
├── server.ts                    # Express server (API + static serve)
├── Dockerfile                   # Multi-stage Docker build
├── vite.config.ts               # Vite build config
├── tsconfig.json                # TypeScript (frontend)
├── tsconfig.server.json         # TypeScript (server build)
└── .env.example                 # Environment template
```

---

## 🔒 Security

- HTTP security headers via `helmet`
- Rate limiting: 50 req/15min (API), 15 req/min (chat)
- Input validation and sanitization on all endpoints
- Non-root Docker user
- JSON body size limit (10kb)
- CSP headers configured

## ♿ Accessibility

- Semantic HTML (`<header>`, `<main>`, `<section>`, `<footer>`)
- ARIA labels on all interactive elements
- `aria-live` regions for dynamic content
- Focus-visible styles for keyboard navigation
- `role="alert"` on error messages
- `aria-busy` on loading states

---

## 📜 License

MIT License. Built for the Google Cloud + Gemini AI Vibe Coding Challenge.

---

> **Disclaimer**: This is an educational application. For official voter services, visit [eci.gov.in](https://eci.gov.in) or [nvsp.in](https://nvsp.in). Helpline: **1950**.
